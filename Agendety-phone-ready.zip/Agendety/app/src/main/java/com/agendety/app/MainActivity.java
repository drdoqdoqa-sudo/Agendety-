package com.agendety.app;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.graphics.Typeface;import android.view.*;import android.view.inputmethod.InputMethodManager;import android.widget.*;import java.text.SimpleDateFormat;import java.util.*;

public class MainActivity extends Activity {
  LinearLayout list; EditText input; android.content.SharedPreferences prefs; ArrayList<Task> tasks=new ArrayList<>();
  static class Task { String text; boolean done; Task(String t,boolean d){text=t;done=d;} }
  @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main); list=findViewById(R.id.list);input=findViewById(R.id.input);prefs=getSharedPreferences("tasks",0); load();
    ((TextView)findViewById(R.id.date)).setText(new SimpleDateFormat("EEEE, d MMMM",Locale.getDefault()).format(new Date()));
    findViewById(R.id.add).setOnClickListener(v->addTask()); input.setOnEditorActionListener((v,a,e)->{addTask();return true;}); render(); }
  void addTask(){String s=input.getText().toString().trim();if(s.isEmpty())return;tasks.add(0,new Task(s,false));save();input.setText("");((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(input.getWindowToken(),0);render();}
  void toggle(int i){tasks.get(i).done=!tasks.get(i).done;save();render();}
  void remove(int i){tasks.remove(i);save();render();}
  void render(){list.removeAllViews(); int active=0; for(Task t:tasks)if(!t.done)active++; if(active==0){TextView empty=label("No tasks yet. Add your first one above.",16,Color.rgb(123,128,148));empty.setPadding(12,28,12,28);list.addView(empty);} for(int i=0;i<tasks.size();i++)if(!tasks.get(i).done)addRow(i); if(tasks.size()-active>0){TextView h=label("DONE • "+(tasks.size()-active),13,Color.rgb(123,128,148));h.setTypeface(Typeface.DEFAULT,Typeface.BOLD);h.setPadding(4,24,4,8);list.addView(h);for(int i=0;i<tasks.size();i++)if(tasks.get(i).done)addRow(i);}}
  TextView label(String s,int sp,int c){TextView v=new TextView(this);v.setText(s);v.setTextSize(sp);v.setTextColor(c);return v;}
  void addRow(final int idx){Task t=tasks.get(idx); LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(14,8,8,8);row.setBackgroundColor(Color.WHITE); LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,64);rp.setMargins(0,0,0,8);row.setLayoutParams(rp);
    CheckBox cb=new CheckBox(this);cb.setChecked(t.done);cb.setButtonTintList(new android.content.res.ColorStateList(new int[][]{new int[]{android.R.attr.state_checked},new int[]{}},new int[]{Color.rgb(91,95,239),Color.rgb(180,184,198)}));cb.setOnClickListener(v->toggle(idx));row.addView(cb,new LinearLayout.LayoutParams(48,48));
    TextView tv=label(t.text,16,t.done?Color.rgb(160,165,184):Color.rgb(23,26,43));tv.setGravity(Gravity.CENTER_VERTICAL);if(t.done)tv.setPaintFlags(tv.getPaintFlags()|android.graphics.Paint.STRIKE_THRU_TEXT_FLAG);row.addView(tv,new LinearLayout.LayoutParams(0,-1,1));
    TextView del=label("×",28,Color.rgb(160,165,184));del.setGravity(Gravity.CENTER);del.setOnClickListener(v->remove(idx));row.addView(del,new LinearLayout.LayoutParams(44,-1)); list.addView(row); }
  void save(){StringBuilder s=new StringBuilder();for(Task t:tasks)s.append(t.done?"1":"0").append("\t").append(android.util.Base64.encodeToString(t.text.getBytes(),0)).append("\n");prefs.edit().putString("data",s.toString()).apply();}
  void load(){String s=prefs.getString("data","");for(String line:s.split("\n")){if(line.trim().isEmpty())continue;String[] p=line.split("\t",2);try{tasks.add(new Task(new String(android.util.Base64.decode(p[1],0)),p[0].equals("1")));}catch(Exception e){}}}
}
