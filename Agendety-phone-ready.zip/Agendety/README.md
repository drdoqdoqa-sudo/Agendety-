# Agendety

Simple Android task app.

Features:
- Add tasks
- Mark tasks Done
- Completed tasks move to DONE section
- Delete tasks
- Tasks persist locally
- Portrait mobile layout

## Build on a phone with GitHub
1. Create a GitHub repository named `Agendety`.
2. Upload the contents of this folder to the repository root.
3. Open **Actions** → **Build Agendety APK** → **Run workflow**.
4. When it finishes, open the workflow run and download the **Agendety-APK** artifact.
5. Extract the downloaded artifact and install `app-debug.apk` on Android.
